

 function misterio() {
    alert("¡Si estudias pasarás el año!");
}